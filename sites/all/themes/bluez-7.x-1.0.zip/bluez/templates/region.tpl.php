<?php
/**
 * @file
 * Bluez theme's implementation to display a region.
 */
?>
  <?php if (!empty($content)): ?>
    <div class="<?php print $classes; ?>">
      <?php print $content; ?>
    </div>
  <?php endif; ?> <!-- /.region -->
